<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!-- TITLE -->
    <title>Social Demo</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">

    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:700,600,400,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Oswald:400' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>

    <!-- CSS LIBRARY -->
    <link rel="stylesheet" type="text/css" href="css/lib/bootstrap.min.css">




    <!-- MAIN STYLE -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/demo.css">
    <link rel="stylesheet" media="screen" href="css/media.css">



    <!--[if lt IE 9]>
        <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
    <![endif]-->
</head>

<!--[if IE 7]> <body class="ie7 lt-ie8 lt-ie9 lt-ie10"> <![endif]-->
<!--[if IE 8]> <body class="ie8 lt-ie9 lt-ie10"> <![endif]-->
<!--[if IE 9]> <body class="ie9 lt-ie10"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->

<body > <!--<![endif]-->

<section id="home-page-bg">

<div class="container">

  

<!-- Body Start -->
<section id="content">
  <div class="row">
     <div class="col-md-6 col-lg-6">
       <div class="text-area">
          <h2 class="text-center text-color">Welcome to Unique</h2>
          <h2 class="text-center text-color">Air Travelers Social Network.</h2>
          <h4 class="text-center text-clr">Jeokoo,</h4>
          <h4 class="text-center ">Your Airplane Seatmate.</h4>
          <button class="btn btn-register">Register Now</button>
       </div>
     </div>
     <div class="col-md-6  col-lg-6">
       <div class="reg-area">
         <aside class="reg-box">
               <h3 class="box-title">Login</h3>
            <form action="" method="post" class="form-group">
              <div class="box-input">
                <input type="text" class="form-control" placeholder="Enter Your Email" name="email" required="true" />
              </div>
              <div class="box-input">
                <input type="password" class="form-control" placeholder="Enter Password" name="password" />
              </div>
              <div class="row">
               <div class="col-md-6">
                 <div class="box-check-box">
                   <input type="checkbox"  name="remember" /> Remember Me
                 </div>
               </div>
               <div class="col-md-6">
                 <div class="box-link">
                   <a href="#" >Forget Password</a>
                 </div>
               </div>
              </div>
              <div class="box-login">
                <input type="submit" class="form-control bg-color" value="Login" name="login" />
              </div>
              
                 <div class="box-line">
                   
                 </div>
               
               
                 <div class="box-or">
                   OR
                 </div>
               
               
                 <div class="box-line-right">
                   
                 </div>
              
              
              <div class="box-login">
                <input type="submit" class="form-control bg-color1" value="Login With Facebook" name="fbLogin" />
              </div>
              <div class="box-login1">
                <input type="submit" class="form-control bg-color2" value="Login With Twiter" name="twiterlogin" />
              </div> 
            </form>
            <div class="box-link text-center padding-bottom">
              <a href="">Don't Have An Account? Register Now</a>
            </div>
         </aside>
       </div>
     </div>
  </div>
</section>
<!-- Body End -->
</div>
</section>
</body>
</html>